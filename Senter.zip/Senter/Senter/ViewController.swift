//
//  ViewController.swift
//  Senter
//
//  Created by muqorrobinaimar on 11/24/17.
//  Copyright © 2017 muqorrobin. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tombol: UISwitch!
    @IBOutlet weak var lbltombol: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    @IBAction func tombol1(_ sender: Any) {
        if tombol.isOn
        {
            lbltombol.text="Switch Is Off"
            tombol.setOn(false, animated: true)
        }
        else
        {
            lbltombol.text="Switch Is On"
            tombol.setOn(true, animated: true)
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

